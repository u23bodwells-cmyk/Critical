@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%LOCALAPPDATA%\CriticalReminders\remind.ps1" -Slot test
