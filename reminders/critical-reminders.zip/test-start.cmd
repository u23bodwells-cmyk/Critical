@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%LOCALAPPDATA%\CriticalReminders\open-critical.ps1" -Mode start -Test
