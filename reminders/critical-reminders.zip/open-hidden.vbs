' Opens Critical without flashing a PowerShell window. Optional argument: home (default) or start
Set sh = CreateObject("WScript.Shell")
dir = CreateObject("Scripting.FileSystemObject").GetParentFolderName(WScript.ScriptFullName)
m = "home"
If WScript.Arguments.Count > 0 Then m = WScript.Arguments(0)
sh.Run "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File """ & dir & "\open-critical.ps1"" -Mode " & m, 0, False
