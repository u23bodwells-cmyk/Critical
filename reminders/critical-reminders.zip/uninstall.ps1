Get-ScheduledTask -TaskName 'Critical reminder*' -ErrorAction SilentlyContinue | Unregister-ScheduledTask -Confirm:$false
Remove-Item (Join-Path $env:LOCALAPPDATA 'CriticalReminders') -Recurse -Force -ErrorAction SilentlyContinue
Write-Host 'Critical reminders removed.' -ForegroundColor Green
