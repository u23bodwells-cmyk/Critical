Get-ScheduledTask -TaskName 'Critical reminder*' -ErrorAction SilentlyContinue | Unregister-ScheduledTask -Confirm:$false
Get-ScheduledTask -TaskName 'Critical start*' -ErrorAction SilentlyContinue | Unregister-ScheduledTask -Confirm:$false
Get-ScheduledTask -TaskName 'Critical open on unlock' -ErrorAction SilentlyContinue | Unregister-ScheduledTask -Confirm:$false
Remove-Item (Join-Path ([Environment]::GetFolderPath('Startup')) 'Critical.lnk') -Force -ErrorAction SilentlyContinue
Remove-Item (Join-Path $env:LOCALAPPDATA 'CriticalReminders') -Recurse -Force -ErrorAction SilentlyContinue
Write-Host 'Critical reminders and the start-up opener are removed.' -ForegroundColor Green
