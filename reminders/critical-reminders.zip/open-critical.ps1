# Opens Critical when you turn on or unlock your PC after 3pm on a school day.
# It only opens once a day, so locking and unlocking again won't keep opening it.
param([switch]$Test)

$now = Get-Date
if (-not $Test) {
    $day = [int]$now.DayOfWeek            # 0 = Sunday, 6 = Saturday
    if ($day -eq 0 -or $day -eq 6) { exit }
    $mins = $now.Hour * 60 + $now.Minute
    if ($mins -lt 900 -or $mins -ge 1290) { exit }   # only between 3pm and 9:30pm

    $mark  = Join-Path $env:LOCALAPPDATA 'CriticalReminders\opened-today.txt'
    $today = $now.ToString('yyyy-MM-dd')
    if ((Test-Path $mark) -and ((Get-Content $mark -Raw).Trim() -eq $today)) { exit }
    Set-Content -Path $mark -Value $today
    Start-Sleep -Seconds 5                # give Wi-Fi a moment after start-up
}

Start-Process 'https://u23bodwells-cmyk.github.io/Critical/critical.html#home'
