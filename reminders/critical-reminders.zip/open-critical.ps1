# Opens Critical in its own app window (not a Chrome tab).
#   -Mode home  : when you turn on or unlock your PC after 3pm on a school day (once a day)
#   -Mode start : at 4:45pm on school days, so your study session starts by itself (once a day)
param([string]$Mode = 'home', [switch]$Test)

$now = Get-Date
if (-not $Test) {
    $day = [int]$now.DayOfWeek            # 0 = Sunday, 6 = Saturday
    if ($day -eq 0 -or $day -eq 6) { exit }
    $mins = $now.Hour * 60 + $now.Minute
    if ($Mode -eq 'start') {
        if ($mins -lt 1005 -or $mins -gt 1020) { exit }   # 4:45 to 5pm only: a PC that was asleep won't open it late
        $mark = Join-Path $env:LOCALAPPDATA 'CriticalReminders\started-today.txt'
    } else {
        if ($mins -lt 900 -or $mins -ge 1290) { exit }    # only between 3pm and 9:30pm
        $mark = Join-Path $env:LOCALAPPDATA 'CriticalReminders\opened-today.txt'
    }
    $today = $now.ToString('yyyy-MM-dd')
    if ((Test-Path $mark) -and ((Get-Content $mark -Raw).Trim() -eq $today)) { exit }
    Set-Content -Path $mark -Value $today
    if ($Mode -ne 'start') { Start-Sleep -Seconds 5 }   # give Wi-Fi a moment after start-up
}

$hash = if ($Mode -eq 'start') { 'start' } else { 'home' }
$url  = "https://u23bodwells-cmyk.github.io/Critical/critical.html#$hash"

# 1) Critical installed as an app (Chrome menu > Cast, save and share > Install page as app)
$sh  = New-Object -ComObject WScript.Shell
$app = $null
$dirs = @(
    (Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\Chrome Apps'),
    (Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs'),
    [Environment]::GetFolderPath('Desktop')
)
foreach ($d in $dirs) {
    if (-not $d -or -not (Test-Path $d)) { continue }
    foreach ($f in (Get-ChildItem -Path $d -Filter 'Critical*.lnk' -ErrorAction SilentlyContinue)) {
        try { $l = $sh.CreateShortcut($f.FullName) } catch { continue }
        if ($l.Arguments -match '--app-id=') { $app = $l; break }
    }
    if ($app) { break }
}
if ($app) {
    Start-Process -FilePath $app.TargetPath -ArgumentList ($app.Arguments + ' --app-launch-url-for-shortcuts-menu-item=' + $url)
    exit
}

# 2) Otherwise, a Chrome app window: no tabs, no address bar, same progress as Critical in Chrome
function Get-Chrome {
    foreach ($k in 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe', 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe') {
        try { $p = (Get-ItemProperty -Path $k -ErrorAction Stop).'(default)'; if ($p -and (Test-Path $p)) { return $p } } catch { }
    }
    foreach ($p in @("$env:ProgramFiles\Google\Chrome\Application\chrome.exe", "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe", "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe")) {
        if ($p -and (Test-Path $p)) { return $p }
    }
    return $null
}
$chrome = Get-Chrome
if ($chrome) {
    $prof = 'Default'
    try {
        $ls = Get-Content (Join-Path $env:LOCALAPPDATA 'Google\Chrome\User Data\Local State') -Raw | ConvertFrom-Json
        if ($ls.profile.last_used) { $prof = [string]$ls.profile.last_used }
    } catch { }
    Start-Process -FilePath $chrome -ArgumentList @("--profile-directory=`"$prof`"", "--app=$url")
} else {
    Start-Process $url
}
