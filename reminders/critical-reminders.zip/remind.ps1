# Critical study reminder. Shows a Windows notification unless you've already studied today.
param([string]$Slot = 'test')

$now   = Get-Date
$today = $now.ToString('yyyy-MM-dd')

# Only fire close to the planned time (a laptop that was asleep shouldn't nag hours late)
if ($Slot -ne 'test') {
    $planned = [datetime]::ParseExact($Slot, 'HHmm', $null)
    $late = ($now - $planned).TotalMinutes
    if ($late -lt -5 -or $late -gt 90) { exit }
}

# Has Critical logged any study today?
$docs = [Environment]::GetFolderPath('MyDocuments')
$file = Join-Path $docs 'Critical\critical-study.json'
$streak = 0
if (Test-Path $file) {
    try {
        $j = Get-Content $file -Raw | ConvertFrom-Json
        if ($j.streak) { $streak = [int]$j.streak }
        if ($Slot -ne 'test' -and $j.lastStudied -eq $today) { exit }
    } catch { }
}

switch ($Slot) {
    '1615'  { $title = 'Home from school? Time for Critical'; $body = 'Even 20 minutes keeps you moving towards the control room.' }
    '1800'  { $title = "You haven't studied yet today";      $body = 'Open Critical and start the timer. A short session still counts.' }
    '2000'  { $title = 'Last call for today';                 $body = 'Still time for a quick Critical session before bed.' }
    default { $title = 'Critical reminders are working';      $body = 'You will get reminders at 4:15pm on school days, then 6pm and 8pm if you have not studied.' }
}
if ($streak -gt 0 -and $Slot -ne 'test') { $body += " Don't lose your $streak-day streak!" }

$url = 'https://u23bodwells-cmyk.github.io/Critical/'
function X([string]$s) { [System.Security.SecurityElement]::Escape($s) }

$xml = @"
<toast activationType="protocol" launch="$url" scenario="reminder">
  <visual>
    <binding template="ToastGeneric">
      <text>$(X $title)</text>
      <text>$(X $body)</text>
    </binding>
  </visual>
  <actions>
    <action content="Open Critical" activationType="protocol" arguments="$url"/>
    <action content="Dismiss" activationType="system" arguments="dismiss"/>
  </actions>
  <audio src="ms-winsoundevent:Notification.Reminder"/>
</toast>
"@

[Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] | Out-Null
[Windows.Data.Xml.Dom.XmlDocument, Windows.Data.Xml.Dom.XmlDocument, ContentType = WindowsRuntime] | Out-Null
$doc = New-Object Windows.Data.Xml.Dom.XmlDocument
$doc.LoadXml($xml)
$appId = '{1AC14E77-02E7-4E5D-B744-2EB1AE5198B7}\WindowsPowerShell\v1.0\powershell.exe'
[Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier($appId).Show([Windows.UI.Notifications.ToastNotification]::new($doc))
