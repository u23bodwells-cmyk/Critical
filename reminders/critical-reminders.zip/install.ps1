# Sets up Critical study reminders and opens Critical when you get home (no admin needed)
$ErrorActionPreference = 'Stop'
$src  = Split-Path -Parent $MyInvocation.MyCommand.Path
$dest = Join-Path $env:LOCALAPPDATA 'CriticalReminders'
New-Item -ItemType Directory -Force -Path $dest | Out-Null
foreach ($f in 'remind.ps1', 'run-hidden.vbs', 'open-critical.ps1', 'open-hidden.vbs') {
    Copy-Item (Join-Path $src $f) $dest -Force
    Unblock-File (Join-Path $dest $f) -ErrorAction SilentlyContinue
}

# Folder the Critical app writes your study time into
$docs = [Environment]::GetFolderPath('MyDocuments')
New-Item -ItemType Directory -Force -Path (Join-Path $docs 'Critical') | Out-Null

$vbs = Join-Path $dest 'run-hidden.vbs'
$settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit (New-TimeSpan -Minutes 5)
$school = 'Monday','Tuesday','Wednesday','Thursday','Friday'
$tasks = @(
    @{ Name = 'Critical reminder 4.15pm'; Slot = '1615'; Trigger = (New-ScheduledTaskTrigger -Weekly -DaysOfWeek $school -At '16:15') },
    @{ Name = 'Critical reminder 4.30pm'; Slot = '1630'; Trigger = (New-ScheduledTaskTrigger -Weekly -DaysOfWeek $school -At '16:30') },
    @{ Name = 'Critical reminder 4.40pm'; Slot = '1640'; Trigger = (New-ScheduledTaskTrigger -Weekly -DaysOfWeek $school -At '16:40') },
    @{ Name = 'Critical reminder 6pm';    Slot = '1800'; Trigger = (New-ScheduledTaskTrigger -Daily -At '18:00') },
    @{ Name = 'Critical reminder 8pm';    Slot = '2000'; Trigger = (New-ScheduledTaskTrigger -Daily -At '20:00') }
)
foreach ($t in $tasks) {
    $action = New-ScheduledTaskAction -Execute 'wscript.exe' -Argument "`"$vbs`" $($t.Slot)"
    Register-ScheduledTask -TaskName $t.Name -Action $action -Trigger $t.Trigger -Settings $settings -Force | Out-Null
}

$openVbs = Join-Path $dest 'open-hidden.vbs'

# Open Critical by itself at 4:45pm on school days (skipped if the PC was off or asleep then)
$startSettings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit (New-TimeSpan -Minutes 5)
$startAction   = New-ScheduledTaskAction -Execute 'wscript.exe' -Argument "`"$openVbs`" start"
Register-ScheduledTask -TaskName 'Critical start 4.45pm' -Action $startAction -Trigger (New-ScheduledTaskTrigger -Weekly -DaysOfWeek $school -At '16:45') -Settings $startSettings -Force | Out-Null

# Open Critical when the PC starts (Startup folder shortcut)
$startup = [Environment]::GetFolderPath('Startup')
$lnk = (New-Object -ComObject WScript.Shell).CreateShortcut((Join-Path $startup 'Critical.lnk'))
$lnk.TargetPath  = Join-Path $env:WINDIR 'System32\wscript.exe'
$lnk.Arguments   = "`"$openVbs`""
$lnk.WindowStyle = 7
$lnk.Description = 'Opens Critical after 3pm on school days'
$lnk.Save()

# ...and when you unlock it (for when it was asleep rather than off)
$unlockOk = $true
try {
    $class  = Get-CimClass -Namespace 'Root/Microsoft/Windows/TaskScheduler' -ClassName 'MSFT_TaskSessionStateChangeTrigger'
    $unlock = New-CimInstance -CimClass $class -ClientOnly -Property @{ StateChange = [uint32]8; UserId = "$env:USERDOMAIN\$env:USERNAME"; Enabled = $true }
    $open   = New-ScheduledTaskAction -Execute 'wscript.exe' -Argument "`"$openVbs`""
    Register-ScheduledTask -TaskName 'Critical open on unlock' -Action $open -Trigger $unlock -Settings $settings -Force | Out-Null
} catch { $unlockOk = $false }

Write-Host ''
Write-Host 'Done! Critical is set up:' -ForegroundColor Green
Write-Host '  - School days: break reminder at 4:15pm, warnings at 4:30pm and 4:40pm.'
Write-Host '  - At 4:45pm Critical opens by itself in its own app window.'
Write-Host '  - Reminders at 6pm and 8pm if you have not studied yet.'
Write-Host '  - Critical opens when you turn on the PC after 3pm on a school day, once a day.'
if ($unlockOk) { Write-Host '  - It also opens when you unlock the PC after it was asleep.' }
else { Write-Host '  - (Opening on unlock could not be set up on this PC. It still opens when the PC starts.)' -ForegroundColor Yellow }
Write-Host ''
Write-Host 'Tip: install Critical as an app so it gets its own icon. In Chrome, open Critical, then'
Write-Host 'menu (three dots) > Cast, save and share > Install page as app. Without that, it still'
Write-Host 'opens in a Chrome app window with no tabs.'
Write-Host ''
Write-Host 'Last step, if you have not done it before: open Critical, tap the timer button,'
Write-Host "and connect it to the folder: $(Join-Path $docs 'Critical')"
Write-Host ''
Write-Host 'Sending a test notification now...'
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $dest 'remind.ps1') -Slot test
