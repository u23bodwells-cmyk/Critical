# Sets up Critical study reminders (no admin needed)
$ErrorActionPreference = 'Stop'
$src  = Split-Path -Parent $MyInvocation.MyCommand.Path
$dest = Join-Path $env:LOCALAPPDATA 'CriticalReminders'
New-Item -ItemType Directory -Force -Path $dest | Out-Null
foreach ($f in 'remind.ps1', 'run-hidden.vbs') {
    Copy-Item (Join-Path $src $f) $dest -Force
    Unblock-File (Join-Path $dest $f) -ErrorAction SilentlyContinue
}

# Folder the Critical app writes your study time into
$docs = [Environment]::GetFolderPath('MyDocuments')
New-Item -ItemType Directory -Force -Path (Join-Path $docs 'Critical') | Out-Null

$vbs = Join-Path $dest 'run-hidden.vbs'
$settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit (New-TimeSpan -Minutes 5)
$school = 'Monday','Tuesday','Wednesday','Thursday','Friday'
$tasks = @(
    @{ Name = 'Critical reminder 4.15pm'; Slot = '1615'; Trigger = (New-ScheduledTaskTrigger -Weekly -DaysOfWeek $school -At '16:15') },
    @{ Name = 'Critical reminder 6pm';    Slot = '1800'; Trigger = (New-ScheduledTaskTrigger -Daily -At '18:00') },
    @{ Name = 'Critical reminder 8pm';    Slot = '2000'; Trigger = (New-ScheduledTaskTrigger -Daily -At '20:00') }
)
foreach ($t in $tasks) {
    $action = New-ScheduledTaskAction -Execute 'wscript.exe' -Argument "`"$vbs`" $($t.Slot)"
    Register-ScheduledTask -TaskName $t.Name -Action $action -Trigger $t.Trigger -Settings $settings -Force | Out-Null
}

Write-Host ''
Write-Host 'Done! Critical reminders are set up:' -ForegroundColor Green
Write-Host '  4:15pm on school days, then 6pm and 8pm if you have not studied yet.'
Write-Host ''
Write-Host 'Last step: open Critical, tap the timer button, and connect it to'
Write-Host "the folder: $(Join-Path $docs 'Critical')"
Write-Host ''
Write-Host 'Sending a test notification now...'
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $dest 'remind.ps1') -Slot test
